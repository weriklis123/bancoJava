package utils;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class AuthSystem {

    private static final String FILE_NAME = "users.txt";
    private Map<String, String> users = new HashMap<>();

    public AuthSystem() {
        loadUsersFromFile();
    }

    // M�todo para registrar um novo usu�rio
    public boolean registerUser(String username, String password) {
        if (users.containsKey(username)) {
            System.out.println("Usu�rio j� existe!");
            return false;
        }

        String hashedPassword = hashPassword(password);
        users.put(username, hashedPassword);
        saveUsersToFile();
        System.out.println("Usu�rio registrado com sucesso!");
        return true;
    }

    // M�todo para autenticar um usu�rio
    public boolean authenticate(String username, String password) {
        String hashedPassword = hashPassword(password);
        if (users.containsKey(username) && users.get(username).equals(hashedPassword)) {
            System.out.println("Autentica��o bem-sucedida!");
            return true;
        }

        System.out.println("Usu�rio ou senha inv�lidos!");
        return false;
    }

    // M�todo para carregar usu�rios do arquivo
    private void loadUsersFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    users.put(parts[0], parts[1]);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo de usu�rios n�o encontrado. Criando um novo.");
        } catch (IOException e) {
            System.out.println("Erro ao carregar usu�rios: " + e.getMessage());
        }
    }

    // M�todo para salvar usu�rios no arquivo
    private void saveUsersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Map.Entry<String, String> entry : users.entrySet()) {
                writer.write(entry.getKey() + "," + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar usu�rios: " + e.getMessage());
        }
    }

    // M�todo para hashear a senha (simples hashing com SHA-256)
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erro ao hashear a senha", e);
        }
    }

    public static void main(String[] args) {
        AuthSystem authSystem = new AuthSystem();

        // Exemplo de uso
        authSystem.registerUser("user1", "password123");
        authSystem.authenticate("user1", "password123"); // Autentica��o bem-sucedida
        authSystem.authenticate("user1", "wrongpassword"); // Falha na autentica��o
    }
}
