package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.util.ArrayList;
import java.util.List;

import model.ContaCorrente;
import model.ContaPoupanca;
import model.Funcionario;

public class DataManager {

    public static void salvarContascc(List<ContaCorrente> contas, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(contas);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void salvarContascp(List<ContaPoupanca> contas, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(contas);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<ContaCorrente> carregarContascc(String filename) {
    	
    	File file = new File(filename);
    	
    	if(file.exists()) {
    		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
    			System.out.println("Arquivo encontrado, carregando...");
    			List<ContaCorrente> cc = (List<ContaCorrente>) ois.readObject();
    			cc.forEach(System.out::println);
    			//return (List<ContaCorrente>) ois.readObject();
    			return cc;
               
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                return null;
            }
    	}else {
    		System.out.println("Arquivo n�o encontrado!");
    		List<ContaCorrente> cc = new ArrayList<ContaCorrente>();
    		try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename));
				oos.writeObject(cc);
				 return null;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	
		/*
		 * try (ObjectInputStream ois = new ObjectInputStream(new
		 * FileInputStream(filename))) { return (List<ContaCorrente>) ois.readObject();
		 * } catch (IOException | ClassNotFoundException e) { e.printStackTrace();
		 * return null; }
		 */
    	 return null;
    }
    
    public static List<ContaPoupanca> carregarContascp(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            return (List<ContaPoupanca>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static void salvarFuncionarios(List<Funcionario> funcionarios, String filename){
    	
    	
    	
    	
    	try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(funcionarios);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static List<Funcionario> carregarFuncionarios(String filename){
    	
    	File file = new File(filename);
    	
    	if(file.exists()) {
    		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
    			return (List<Funcionario>) ois.readObject();
    		} catch (Exception e) {
    			e.printStackTrace();
    			return null;
    		}
    		
    	}else {
    		System.out.println("Arquivo n�o encontrado!");
    		List<Funcionario> func = new ArrayList<Funcionario>();
    		try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename));
				oos.writeObject(func);
				 return null;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				
				e.printStackTrace();
				return null;
			}
    		
    	}
    	
    	
    	
    }
}
