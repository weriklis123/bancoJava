package controller;

import java.util.ArrayList;
import java.util.List;

import model.Conta;
import model.ContaCorrente;
import model.ContaPoupanca;
import model.Funcionario;
import utils.DataManager;

public class BancoController {
	
	List<ContaCorrente> cc = new ArrayList<ContaCorrente>();
	List<ContaPoupanca> cp = new ArrayList<ContaPoupanca>();
	List<Funcionario> func = new ArrayList<Funcionario>();
	
	String arquivoCC = "C:\\Users\\crist\\OneDrive\\Desktop\\cc.dat";
	String arquivoCP = "C:\\Users\\crist\\OneDrive\\Desktop\\cp.dat";
	
	public void abrirConta(Conta conta) {
		if(conta.getTipoConta() == 0) {
			cc = DataManager.carregarContascc(arquivoCC);
			cc.add((ContaCorrente) conta);
			DataManager.salvarContascc(cc, arquivoCC);
		}else {
			cp = DataManager.carregarContascp(arquivoCP);
			cp.add((ContaPoupanca) conta);
			DataManager.salvarContascp(cp, arquivoCP);
		}
		
		
	}
	
	public void encerrarConta(int numero_conta,int tipo_conta) {
		if(tipo_conta == 0) {
			cc = DataManager.carregarContascc(arquivoCC);
		
			for (int i = 0; i < cc.size(); i++) {
				ContaCorrente conta = cc.get(i);
				if(conta.getNumero() == numero_conta) {
					cc.remove(i);
				}
			}
			
		}else {
			cp = DataManager.carregarContascp(arquivoCP);
			for (int i = 0; i < cp.size(); i++) {
				ContaPoupanca conta = cp.get(i);
				if(conta.getNumero() == numero_conta) {
					cp.remove(i);
				}
			}
		}
		
	}
	
	public ContaCorrente consultarContacc(int numero_conta) {
		
		cc = DataManager.carregarContascc(arquivoCC);
		
		int teste = cc.indexOf(numero_conta);
		
		
		
		for (int i = 0; i < cc.size(); i++) {
			ContaCorrente testecc = cc.get(i);
			if(testecc.getNumero() == numero_conta) {
				return testecc;
			}
			//System.out.println(testecc.getNumero());
		}
		
		
		System.out.println(teste);
		System.out.println("numero da conta "+numero_conta);
		return null;

	}
	
	public void salvarDados() {
		DataManager.salvarContascc(cc, arquivoCC);
		
	}
	
	public void carregarDados() {
		
	}
	
	public void cadastrarFuncionario(Funcionario funcionario) {
		func = DataManager.carregarFuncionarios("C:\\Users\\crist\\OneDrive\\Desktop\\fun.dat");
		func.add(funcionario);
		DataManager.salvarFuncionarios(func, "C:\\Users\\crist\\OneDrive\\Desktop\\fun.dat");
	}
	
	
}
