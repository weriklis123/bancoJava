package model;

import java.io.Serializable;

public class Funcionario implements Serializable{
	
	private String nome_funcionario;
	private int cpf_funcionario;
	private String telefone_funcionario;
	private String endereco_funcionario;
	
	
	public String getNome_funcionario() {
		return nome_funcionario;
	}
	public void setNome_funcionario(String nome_funcionario) {
		this.nome_funcionario = nome_funcionario;
	}
	public int getCpf_funcionario() {
		return cpf_funcionario;
	}
	public void setCpf_funcionario(int cpf_funcionario) {
		this.cpf_funcionario = cpf_funcionario;
	}
	public String getTelefone_cliente() {
		return telefone_funcionario;
	}
	public void setTelefone_cliente(String telefone_cliente) {
		this.telefone_funcionario = telefone_cliente;
	}
	public String getEndereco_funcionario() {
		return endereco_funcionario;
	}
	public void setEndereco_funcionario(String endereco_funcionario) {
		this.endereco_funcionario = endereco_funcionario;
	}
	public Funcionario(String nome_funcionario, int cpf_funcionario, String telefone_funcionario,
			String endereco_funcionario) {
		super();
		this.nome_funcionario = nome_funcionario;
		this.cpf_funcionario = cpf_funcionario;
		this.telefone_funcionario = telefone_funcionario;
		this.endereco_funcionario = endereco_funcionario;
	}
	
	
	

}
