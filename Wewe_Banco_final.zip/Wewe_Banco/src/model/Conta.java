package model;

import java.io.Serializable;

public  class Conta implements Serializable{

	private int numero;
	private float saldo;
	private int tipoConta;
	
	public Conta(int numero, float saldo, int tipoConta) {
		//super();
		this.numero = numero;
		this.saldo = saldo;
		this.tipoConta = tipoConta;
	}
	
	

	public Conta() {
		super();
	}



	public void depositar(int numero_conta, float valor) {
		
		this.saldo = this.saldo + valor;

		
	};
	
	public 	 void sacar(int numero_conta, float valor) {
		
		this.saldo = this.saldo - valor;
		
	}
	
	public float consultarSaldo(int numero_conta) {
		
		return this.saldo;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}

	public int getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(int tipoConta) {
		this.tipoConta = tipoConta;
	}
	
	
	
	
	
	
	
}
