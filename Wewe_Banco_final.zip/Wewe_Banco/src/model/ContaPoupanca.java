package model;

public class ContaPoupanca  extends Conta{
	
	public ContaPoupanca(int numero, float saldo, int tipoConta) {
		super(numero, saldo, tipoConta);
		// TODO Auto-generated constructor stub
	}

	private int dia_vencimento;
	

}
