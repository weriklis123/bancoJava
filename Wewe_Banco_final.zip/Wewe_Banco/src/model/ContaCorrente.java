package model;

import java.io.Serializable;

public class ContaCorrente extends Conta implements Serializable{



	public ContaCorrente(int numero, float saldo, int tipoConta, float limite_conta) {
		super(numero, saldo, tipoConta);
		this.limite_conta = limite_conta;
	}
	

	public ContaCorrente() {
		
	}


	private float limite_conta;

	public float verificarLimite(int nmero_conta) {
		return this.limite_conta;
	}


	public float getLimite_conta() {
		return limite_conta;
	}


	public void setLimite_conta(float limite_conta) {
		this.limite_conta = limite_conta;
	}
	
	

}
