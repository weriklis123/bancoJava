package model;

import java.io.Serializable;

public class Cliente implements Serializable{
	
	private String nome_cliente;
	private int cpf_cliente;
	private String telefone_cliente;
	private String endereco_cliente;
	
	
	
	
	
	public Cliente(String nome_cliente, int cpf_cliente) {
		super();
		this.nome_cliente = nome_cliente;
		this.cpf_cliente = cpf_cliente;
	}
	public String getNome_cliente() {
		return nome_cliente;
	}
	public void setNome_cliente(String nome_cliente) {
		this.nome_cliente = nome_cliente;
	}
	public int getCpf_cliente() {
		return cpf_cliente;
	}
	public void setCpf_cliente(int cpf_cliente) {
		this.cpf_cliente = cpf_cliente;
	}
	public String getTelefone_cliente() {
		return telefone_cliente;
	}
	public void setTelefone_cliente(String telefone_cliente) {
		this.telefone_cliente = telefone_cliente;
	}
	public String getEndereco_cliente() {
		return endereco_cliente;
	}
	public void setEndereco_cliente(String endereco_cliente) {
		this.endereco_cliente = endereco_cliente;
	}
	
	
	
	

}
