package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaSaqueCliente extends JFrame{
	private JTextField textNumConta;
	private JTextField textSaldoOut;
	public TelaSaqueCliente() {
		setSize(300,150);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Saque");
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNumConta = new JLabel("N\u00FAmero da Conta:");
		lblNumConta.setBounds(27, 34, 88, 14);
		panel.add(lblNumConta);
		
		textNumConta = new JTextField();
		textNumConta.setBounds(125, 31, 219, 20);
		panel.add(textNumConta);
		textNumConta.setColumns(10);
		
		JLabel lblValDeposito = new JLabel("Valor:");
		lblValDeposito.setBounds(27, 59, 46, 14);
		panel.add(lblValDeposito);
		
		textSaldoOut = new JTextField();
		textSaldoOut.setBounds(125, 56, 219, 20);
		panel.add(textSaldoOut);
		textSaldoOut.setColumns(10);
		
		JButton btnSacar = new JButton("Sacar");
		btnSacar.setBounds(181, 172, 89, 23);
		panel.add(btnSacar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(181, 206, 89, 23);
		panel.add(btnSair);
	}

}
