package view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.BancoController;
import model.Cliente;
import model.ContaCorrente;
import model.ContaPoupanca;

public class TelaCriarConta extends JFrame{
	private JTextField textNumeroConta;
	private JTextField textNome;
	private JTextField textCpf;
	private JTextField textLimiteConta;
	public TelaCriarConta() {
		setTitle("Cria��o de conta");
		setSize(375,323);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNumeroConta = new JLabel("N\u00FAmero da Conta:");
		lblNumeroConta.setBounds(31, 35, 96, 14);
		panel.add(lblNumeroConta);
		
		textNumeroConta = new JTextField();
		textNumeroConta.setBounds(123, 32, 171, 20);
		panel.add(textNumeroConta);
		textNumeroConta.setColumns(10);
		
		JLabel lblTipoConta = new JLabel("Tipo da Conta:");
		lblTipoConta.setBounds(31, 60, 86, 14);
		panel.add(lblTipoConta);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Conta Corrente", "Conta Poupan\u00E7a"}));
		comboBox.setBounds(123, 56, 171, 22);
		panel.add(comboBox);
		
		JButton btnCriarConta = new JButton("Criar");
		btnCriarConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int tipo_conta = comboBox.getSelectedIndex();
				String nome = textNome.getText();
				int cpf = Integer.valueOf(textCpf.getText());
				int numero_conta = Integer.valueOf(textNumeroConta.getText());
				int limite_conta = Integer.valueOf(textLimiteConta.getText());
				
				Cliente cliente = new Cliente(nome,cpf);
				
				if(tipo_conta == 0) {
					ContaCorrente cc = new ContaCorrente(numero_conta,0,tipo_conta,limite_conta);
					BancoController bancoController = new BancoController();
					bancoController.abrirConta(cc);
					//bancoController.salvarDados();
				}else {
					ContaPoupanca cp =new ContaPoupanca(numero_conta, 0, tipo_conta);
					BancoController bancoController = new BancoController(); 
					bancoController.abrirConta(cp);
					bancoController.salvarDados();
				}
				
				
				
			}
		});
		btnCriarConta.setBounds(144, 195, 89, 23);
		panel.add(btnCriarConta);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(144, 229, 89, 23);
		panel.add(btnSair);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(31, 85, 46, 14);
		panel.add(lblNome);
		
		textNome = new JTextField();
		textNome.setBounds(123, 82, 171, 20);
		panel.add(textNome);
		textNome.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setBounds(31, 110, 46, 14);
		panel.add(lblCpf);
		
		textCpf = new JTextField();
		textCpf.setBounds(123, 107, 171, 20);
		panel.add(textCpf);
		textCpf.setColumns(10);
		
		JLabel lblLimiteConta = new JLabel("Limite da Conta:");
		lblLimiteConta.setBounds(31, 135, 86, 14);
		panel.add(lblLimiteConta);
		
		textLimiteConta = new JTextField();
		textLimiteConta.setBounds(123, 132, 171, 20);
		panel.add(textLimiteConta);
		textLimiteConta.setColumns(10);
	}
}
