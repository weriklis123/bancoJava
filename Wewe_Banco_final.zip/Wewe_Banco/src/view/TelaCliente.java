package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaCliente extends JFrame{
	public TelaCliente() {
		setTitle("Banco Malvader Tela de Cliente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,300);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnSaldo = new JButton("Saldo");
		btnSaldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaSaldoCliente tela = new TelaSaldoCliente();
				tela.show();
			}
		});
		btnSaldo.setBounds(77, 11, 109, 23);
		panel.add(btnSaldo);
		
		JButton btnDeposito = new JButton("Dep\u00F3sito");
		btnDeposito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaDepositoCliente tela = new TelaDepositoCliente();
				tela.show();
			}
		});
		btnDeposito.setBounds(77, 48, 109, 23);
		panel.add(btnDeposito);
		
		JButton btnSaque = new JButton("Saque");
		btnSaque.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaSaqueCliente tela = new TelaSaqueCliente();
				tela.show();
			}
		});
		btnSaque.setBounds(77, 85, 109, 23);
		panel.add(btnSaque);
		
		JButton btnExtrato = new JButton("Extrato*");
		btnExtrato.setBounds(77, 122, 109, 23);
		panel.add(btnExtrato);
		
		JButton btnConsultarLimite = new JButton("Consultar Limite");
		btnConsultarLimite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaConsultarLimiteCliente tela = new TelaConsultarLimiteCliente();
				tela.show();
			}
		});
		btnConsultarLimite.setBounds(77, 159, 109, 23);
		panel.add(btnConsultarLimite);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(87, 196, 89, 23);
		panel.add(btnSair);
		
	}

}
