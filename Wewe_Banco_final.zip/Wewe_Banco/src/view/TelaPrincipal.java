package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;

public class TelaPrincipal extends JFrame{
	public TelaPrincipal() {
		setTitle("Banco Malvader");
		setSize(300,238);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(null);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnFuncionario = new JButton("Funcionario");
		btnFuncionario.setBounds(97, 25, 89, 23);
		panel.add(btnFuncionario);
		
		JButton btnCliente = new JButton("Cliente");
		btnCliente.setBounds(97, 82, 89, 23);
		panel.add(btnCliente);
		
		JButton btnSair = new JButton("Sair");
		btnSair.setBounds(97, 144, 89, 23);
		panel.add(btnSair);
		
		
		
	}

}
