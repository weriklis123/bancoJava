package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class TelaFuncionario extends JFrame{
	public TelaFuncionario() {
		setTitle("Banco Malvader Tela de Funcion�rio");
		setSize(400,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnAberturaConta = new JButton("Abertura de Conta");
		btnAberturaConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaCriarConta telaCriConta = new TelaCriarConta();
				telaCriConta.show();
			}
		});
		btnAberturaConta.setBounds(111, 31, 161, 23);
		panel.add(btnAberturaConta);
		
		JButton btnEncerramento = new JButton("Encerramento de Conta");
		btnEncerramento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaEncerramentoConta ence= new TelaEncerramentoConta();
				ence.show();
				
			}
		});
		btnEncerramento.setBounds(111, 99, 161, 23);
		panel.add(btnEncerramento);
		
		JButton btnConsultaDados = new JButton("Consulta de Dados");
		btnConsultaDados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ConsultaDeDados cons = new ConsultaDeDados();
				cons.show();
			}
		});
		btnConsultaDados.setBounds(111, 133, 161, 23);
		panel.add(btnConsultaDados);
		
		JButton btnAlteracaoDados = new JButton("Altera\u00E7\u00E3o de Dados*");
		btnAlteracaoDados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnAlteracaoDados.setBounds(111, 167, 161, 23);
		panel.add(btnAlteracaoDados);
		
		JButton btnCadastroFuncionario = new JButton("Cadastro de Funcion\u00E1rio");
		btnCadastroFuncionario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaCadastroFuncionario cad = new TelaCadastroFuncionario();
				cad.show();
			}
		});
		btnCadastroFuncionario.setBounds(111, 65, 161, 23);
		panel.add(btnCadastroFuncionario);
		
		JButton btnGeracaoRelatorio = new JButton("Gera\u00E7\u00E3o de Relat\u00F3rios*");
		btnGeracaoRelatorio.setBounds(111, 201, 161, 23);
		panel.add(btnGeracaoRelatorio);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setForeground(Color.RED);
		btnSair.setBounds(147, 288, 89, 23);
		panel.add(btnSair);
	}

}
