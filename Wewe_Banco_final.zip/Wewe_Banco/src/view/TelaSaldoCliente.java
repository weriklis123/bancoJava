package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaSaldoCliente extends JFrame{
	private JTextField textNumConta;
	private JTextField textSaldoOut;
	public TelaSaldoCliente() {
		setSize(300,150);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Consulta de Saldo");
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNumConta = new JLabel("N\u00FAmero da Conta:");
		lblNumConta.setBounds(27, 34, 88, 14);
		panel.add(lblNumConta);
		
		textNumConta = new JTextField();
		textNumConta.setBounds(125, 31, 219, 20);
		panel.add(textNumConta);
		textNumConta.setColumns(10);
		
		JLabel lblSaldo = new JLabel("Saldo:");
		lblSaldo.setBounds(27, 118, 46, 14);
		panel.add(lblSaldo);
		
		textSaldoOut = new JTextField();
		textSaldoOut.setEditable(false);
		textSaldoOut.setBounds(125, 115, 219, 20);
		panel.add(textSaldoOut);
		textSaldoOut.setColumns(10);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(181, 172, 89, 23);
		panel.add(btnConsultar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(181, 206, 89, 23);
		panel.add(btnSair);
	}

}
