package view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.BancoController;
import model.Funcionario;

public class TelaCadastroFuncionario extends JFrame{
	private JTextField textCPF;
	private JTextField textNome;
	private JTextField textTelefone;
	private JTextField textEndereco;
	public TelaCadastroFuncionario() {
		setSize(400,400);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNomeFuncionario = new JLabel("Nome:");
		lblNomeFuncionario.setBounds(25, 37, 46, 14);
		panel.add(lblNomeFuncionario);
		
		JLabel lblCPF = new JLabel("CPF:");
		lblCPF.setBounds(25, 62, 46, 14);
		panel.add(lblCPF);
		
		textCPF = new JTextField();
		textCPF.setBounds(81, 59, 219, 20);
		panel.add(textCPF);
		textCPF.setColumns(10);
		
		textNome = new JTextField();
		textNome.setBounds(81, 34, 219, 20);
		panel.add(textNome);
		textNome.setColumns(10);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = textNome.getText();
				int cpf = Integer.valueOf(textCPF.getText()) ;
				String tel = textTelefone.getText();
				String endereco = textEndereco.getText();
				
				Funcionario func = new Funcionario(nome, cpf, tel, endereco);
				
				BancoController bc = new BancoController();
				
				bc.cadastrarFuncionario(func);
			}
		});
		btnSalvar.setBounds(146, 155, 89, 23);
		panel.add(btnSalvar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(146, 189, 89, 23);
		panel.add(btnSair);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setBounds(25, 87, 46, 14);
		panel.add(lblTelefone);
		
		textTelefone = new JTextField();
		textTelefone.setBounds(81, 84, 219, 20);
		panel.add(textTelefone);
		textTelefone.setColumns(10);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o:");
		lblEndereco.setBounds(25, 112, 59, 14);
		panel.add(lblEndereco);
		
		textEndereco = new JTextField();
		textEndereco.setBounds(81, 109, 219, 20);
		panel.add(textEndereco);
		textEndereco.setColumns(10);
	}

}
