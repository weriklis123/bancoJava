package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import controller.BancoController;
import model.ContaCorrente;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class ConsultaDeDados extends JFrame{
	private JTextField textNumeroConta;
	private JTextField textNumeroContaOut;
	private JTextField textTipoContaOut;
	private JTextField textLimiteConta;
	public ConsultaDeDados() {
		setTitle("Consulta de Dados");
		setSize(400,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.controlHighlight);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblDigiteConta = new JLabel("Digite o n\u00FAmero da conta:");
		lblDigiteConta.setBounds(10, 24, 124, 14);
		panel.add(lblDigiteConta);
		
		textNumeroConta = new JTextField();
		textNumeroConta.setBounds(144, 21, 230, 20);
		panel.add(textNumeroConta);
		textNumeroConta.setColumns(10);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int num_conta = Integer.valueOf(textNumeroConta.getText());
				
				ContaCorrente cc = new ContaCorrente();
				BancoController bc = new BancoController();
				
				cc = bc.consultarContacc(num_conta);
				
				
				textNumeroContaOut.setText(String.valueOf(cc.getNumero()));
				if(cc.getTipoConta() == 0) {
					textTipoContaOut.setText("Conta Corrente");
				}else {
					textTipoContaOut.setText("Conta Poupan�a");
				}
				textLimiteConta.setText(String.valueOf(cc.getLimite_conta()));
				
				
			}
		});
		
		
		btnConsultar.setBounds(62, 316, 89, 23);
		panel.add(btnConsultar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(182, 316, 89, 23);
		panel.add(btnSair);
		
		JLabel lblNumeroConta = new JLabel("N\u00BA da Conta:");
		lblNumeroConta.setBounds(10, 113, 124, 14);
		panel.add(lblNumeroConta);
		
		textNumeroContaOut = new JTextField();
		textNumeroContaOut.setEditable(false);
		textNumeroContaOut.setBounds(144, 110, 86, 20);
		panel.add(textNumeroContaOut);
		textNumeroContaOut.setColumns(10);
		
		JLabel lblTipoConta = new JLabel("Tipo da Conta");
		lblTipoConta.setBounds(10, 138, 124, 14);
		panel.add(lblTipoConta);
		
		textTipoContaOut = new JTextField();
		textTipoContaOut.setEditable(false);
		textTipoContaOut.setBounds(144, 135, 86, 20);
		panel.add(textTipoContaOut);
		textTipoContaOut.setColumns(10);
		
		JLabel lblLimiteConta = new JLabel("Limite da Conta:");
		lblLimiteConta.setBounds(10, 172, 89, 14);
		panel.add(lblLimiteConta);
		
		textLimiteConta = new JTextField();
		textLimiteConta.setEditable(false);
		textLimiteConta.setBounds(144, 169, 86, 20);
		panel.add(textLimiteConta);
		textLimiteConta.setColumns(10);
	}
}
