package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import utils.AuthSystem;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaLogin extends JFrame{
	private JTextField textUsuario;
	private JPasswordField passwordField;
	public TelaLogin() {
		setTitle("Banco Malvader Login");
		setSize(300,150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel labelUsuario = new JLabel("Usu�rio");
		labelUsuario.setBounds(10,20,80,25);
		panel.add(labelUsuario);
		
		JLabel labelSenha = new JLabel("Senha");
		labelSenha.setBounds(10, 50, 80, 25);
		panel.add(labelSenha);
		
		textUsuario = new JTextField(20);
		textUsuario.setBounds(100, 20, 165, 25);
		panel.add(textUsuario);
		textUsuario.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(100, 50, 165, 25);
		panel.add(passwordField);
		
		JButton btnFuncionario = new JButton("Funcion\u00E1rio");
		btnFuncionario.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				AuthSystem auth = new AuthSystem();
				//auth.registerUser("cristhian", "1234");
				
				
				
				if(auth.authenticate(textUsuario.getText(), passwordField.getText())) {
					TelaFuncionario telafunc = new TelaFuncionario();
					telafunc.show();
					setVisible(false);
					dispose();
				}else {
					JOptionPane.showMessageDialog(null, "Usu�rio e/ou senha incorretos!", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				
				
				
			}
		});
		btnFuncionario.setBounds(18, 77, 114, 23);
		panel.add(btnFuncionario);
		
		JButton btnUsuario = new JButton("Cliente");
		btnUsuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AuthSystem auth = new AuthSystem();
				
				
				
				
				if(auth.authenticate(textUsuario.getText(), passwordField.getText())) {
					TelaCliente telaCli = new TelaCliente();
					telaCli.show();
					setVisible(false);
					dispose();
				}else {
					JOptionPane.showMessageDialog(null, "Usu�rio e/ou senha incorretos!", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				
				
				
				
				
			}
		});
		btnUsuario.setBounds(150, 77, 114, 23);
		panel.add(btnUsuario);
		
		
		
		
		
		
	}
	
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaLogin frame = new TelaLogin();
            frame.setVisible(true);
        });
    }
}
