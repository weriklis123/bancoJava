package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;

import controller.BancoController;
import model.ContaCorrente;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class TelaEncerramentoConta extends JFrame{
	private JTextField textNumeroConta;
	public TelaEncerramentoConta() {
		
		setSize(400,400);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblDigiteConta = new JLabel("Digite o n\u00FAmero da conta:");
		lblDigiteConta.setBounds(21, 33, 136, 14);
		panel.add(lblDigiteConta);
		
		textNumeroConta = new JTextField();
		textNumeroConta.setBounds(167, 30, 178, 20);
		panel.add(textNumeroConta);
		textNumeroConta.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Conta Corrente", "Conta Poupan\u00E7a"}));
		comboBox.setBounds(167, 65, 178, 22);
		panel.add(comboBox);
		
		JButton btnEncerrar = new JButton("Encerrar Conta");
		btnEncerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					BancoController bc = new BancoController();
					bc.encerrarConta(Integer.valueOf(textNumeroConta.getText()), comboBox.getSelectedIndex());
			}
		});
		btnEncerrar.setBounds(167, 159, 105, 23);
		panel.add(btnEncerrar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnSair.setBounds(167, 193, 105, 23);
		panel.add(btnSair);
		
		JLabel lblTipoConta = new JLabel("Tipo da Conta:");
		lblTipoConta.setBounds(21, 69, 124, 14);
		panel.add(lblTipoConta);
		
		
	}
}
